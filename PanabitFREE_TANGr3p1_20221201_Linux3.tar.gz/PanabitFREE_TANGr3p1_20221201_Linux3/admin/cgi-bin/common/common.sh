#!/bin/sh

RAMDISK="/usr/ramdisk"
. ${RAMDISK}/PG.conf

PGPATH="${RAMDISK}"
PGBIN="${PGPATH}/bin"
FLOWEYE="${PGBIN}/floweye"
ESCTOOL="${PGBIN}/esctool"
URLENCODE="${PGBIN}/urlencode"

USER_DIR="${RAMDISK}/etc/webuser"
EVENTFILE="${PGETC}/log/pending_events"

. ${PGPATH}/etc/panabit.inf
[ -f "${RAMDISK}/etc/sysname.conf" ] && . ${RAMDISK}/etc/sysname.conf


if [ -e /usr/ramdisk/datalog/keepme ]; then
	RAMLOG="/usr/ramdisk/datalog"
else
	RAMLOG="${DATAPATH}"
fi

if [ "${PALANG}" = "en" ]; then
	CLANG_01="Status"
	CLANG_02="Traffic"
	CLANG_03="Trend"
	CLANG_04="Configure"
	CLANG_05="DHCP|Server"
	CLANG_06="Status"
	CLANG_07="Trend"
	CLANG_08="Log"
	CLANG_09="Top|Apps"
	CLANG_010="OnlineUser"
	CLANG_011="Any IP"
	CLANG_012="IP Group"
	CLANG_013="Operation deny"
	CLANG_014="Session"
	CLANG_015="Node"
	CLANG_016="BPS (out / in)"
	CLANG_017="Rate (out / in)"
	CLANG_018="Agent rate (out / in)"
	CLANG_019="Account Information"
	CLANG_020="MAC"
	CLANG_021="OutBytes"
	CLANG_022="InBytes"
	CLANG_023="OutBPS(cur)"
	CLANG_024="InBPS(cur)"
	CLANG_025="Rate limit (in / out, kbps)"
	CLANG_026="Online time (s)"
	CLANG_027="Virtual identity"
	CLANG_028="Share (IE / CH / Weighted)"
	CLANG_029="Mobile"
	CLANG_030="Realtime"
	CLANG_031="The request contains an illegal string"
fi

afm_dialog_msg()
{
	echo "<script language=javascript>"
	echo "alert(\"$1\");"
	echo "</script>"
}

afm_window_close()
{
	echo "<script language=javascript>"
	echo "window.close();"
	echo "</script>"
}

cgi_print_mod_header2()
{
	local width

	width=$2
	[ "${width}" = "" ] && width=700
	echo "<div style=\"width:${width};height:28;border-bottom:1px solid #e0e0e0;\">"
	echo "<ul class=\"nav nav-tabs\">"

	for capurl in ${MOD_TAB_LIST}
	do
		cap=`echo ${capurl} | cut -d'#' -f1`
		url=`echo ${capurl} | cut -d'#' -f2`
		if [ "${cap}" = "$1" ]; then
			echo "<li class=active><a href=\"${url}\">${cap}</a></li>"
		else
			echo "<li><a href=\"${url}\">${cap}</a></li>"
		fi
	done
	
	echo "</ul>"
	echo "</div>"
}


# redirect current page to the designated page
# @param arg1 time to wait
# @param arg2 url of the designated page
# @return 
afm_load_page()
{
    echo "<META HTTP-EQUIV=REFRESH CONTENT=\"$1;URL=$2\">"
}

# to see if arg1 is digit number
# @param arg1
# @return 1(yes), 0(no)
afm_isdigit()
{
	local ret=""

	ret=`echo $1 | sed -e "s/[0-9]//g"`
	[ "${ret}" = "" -o "${ret}" = "-" ] && return 1
	return 0
}

# @param arg1 the number
# @param arg2 begin number
# @param arg3 end number
# @return 1(yes) 0(no)
afm_isbetween()
{
	local ret=""

	ret=`echo $1 | sed -e "s/[0-9]//g"`
	[ "${ret}" != "" -a "${ret}" != "-" ] && return 0
	
	[ $1 -ge $2 -a $1 -le $3 ] && return 1
	return 0
}

# to see if arg1 is an IP address
# @param arg1
# @return 1(yes), 0(no)
afm_isipaddr()
{
	local v=""

	v=`echo $1 | cut -d'.' -f1`
	afm_isbetween "$v" 0 255
	[ "$?" = "0" ] && return 0

	v=`echo $1 | cut -d'.' -f2`
	afm_isbetween "$v" 0 255
	[ "$?" = "0" ] && return 0

	v=`echo $1 | cut -d'.' -f3`
	afm_isbetween "$v" 0 255
	[ "$?" = "0" ] && return 0

	v=`echo $1 | cut -d'.' -f4`
	afm_isbetween "$v" 0 255
	[ "$?" = "0" ] && return 0

	v=`echo $1 | cut -d'.' -f5`
	[ "$v" != "" ] && return 0

	return 1 
}

cgi_print_mod_header()
{
	echo "<div class=\"nav-tab\" style=\"margin-bottom:5px;\">"
	echo "<ul>"

	for capurl in ${MOD_TAB_LIST}
	do
		cap=`echo ${capurl} | cut -d'#' -f1`
		til=`echo ${cap} | tr "|" " "`
		url=`echo ${capurl} | cut -d'#' -f2`
		if [ "${cap}" = "$1" ]; then
			echo "<li class=active><a href=\"${url}\">${til}</a></li>"
		else
			echo "<li><a href=\"${url}\">${til}</a></li>"
		fi
	done

	echo "</ul>"
	echo "</div>"
}

cgi_show_title()
{
	title=`echo $1 | awk -F'>' '{print $(NF)}'`
	echo "<div class=\"nav-tab\">"
	echo "<ul>"
	echo "<li class=active><a>${title}</a></li>"
	echo "</ul>"
	echo "</div>"
}

cgi_show_iptype()
{
	local anyselect=""
	local netselect=""
	local rngselect=""

	case "$1" in
		"any")
			anyselect="selected"
		;;
		"net")
			netselect="selected"
		;;
		"iprange")
			rngselect="selected"
		;;
		"range")
			rngselect="selected"
		;;
	esac

	echo "<option value=\"any\" ${anyselect}>${CLANG_011:=�����ַ}</option>"
	echo "<option value=\"net\" ${netselect}>xxx.xxx.xxx.xxx/nn</option>"
	echo "<option value=\"range\" ${rngselect}>n.n.n.n-m.m.m.m</option>"

	if [ "${tblexists}" != "" ]; then
		if [ "$1" = "table" ]; then
			echo "<option value=\"table\" selected>${CLANG_012:=IPȺ��}</option>"
		else
			echo "<option value=\"table\">${CLANG_012:=IPȺ��}</option>"
		fi
	fi
}

cgi_show_usrgrp()
{
	local idname=$1
	local gid

	${FLOWEYE} pppoeippool list | while read pid pname start end theothers
	do
		if [ "${idname}" = "pppoe.${pid}" -o "${idname}" = "${pname}" ]; then
			echo "<option value=\"pppoe.${pid}\" selected>${pname}</option>"
		else
			echo "<option value=\"pppoe.${pid}\">${pname}</option>"
		fi
	done
}

operator_check()
{
	url=$1
	level=1
	aes_name=`${ESCTOOL} -e ${PANABIT_USER}`
	ufile=${USER_DIR}/${aes_name}

	[ -f ${ufile} ] && . ${ufile}

	if [ "${level}" -gt 1 ]; then
		afm_dialog_msg "${CLANG_013:=����Ȩ�޲���}!"
		afm_load_page 0 "${url}"
		exit 0
	fi
}

cgi_show_app_info()
{
	local appid="$1"
	local width=$2
	local nameval

	wid8=$((${width} / 8))
	wid4=$((${width} / 4))	

	output=`${FLOWEYE} app get ${CGI_appid}`
	if [ "${output}" != "" ]; then
		for nameval in ${output}; do
			eval "${nameval}"
		done
	fi

	echo "<table width=${width} border=0 cellspacing=1 cellpadding=1>
<tr id=tblhdr height=22>
	<td width=${wid8} align=right>${CLANG_014:=������}</td>
	<td width=${wid8} align=right>${CLANG_015:=�ڵ���}</td>
	<td width=${wid4} align=right>${CLANG_016:=����(����/����)}</td>
	<td width=${wid4} align=right>${CLANG_017:=����(����/����)}</td>
	<td width=* align=right>${CLANG_018:=��������(����/����)}</td>
</tr>
<tr id=row1 height=22>
	<td align=right>${flowcnt}</td>
	<td align=right>${nodecnt}</td>
	<td align=right>${upbytes}/${downbytes}</td>
	<td align=right>${upbps}/${downbps}</td>
	<td align=right>${nat_upbps}/${nat_downbps}</td>
</tr>
</table>"
}

cgi_show_ipobj_info()
{
	local usrname;
	local lmacstr;

	if [ "${upool}" != "" ]; then
		usrname="${upool}/${nbname}"
	else
		usrname="${nbname}"
	fi

	if [ "${snmpmac}" = "1" ]; then
		lmacstr="${mac}[S]"
	else
		lmacstr="${mac}"
	fi

	echo "<table width=800 border=0 cellspacing=1 cellpadding=1>
<tr id=tblhdr>
	<td width=160 align=right>${CLANG_019:=�˺���Ϣ}</td>
	<td width=130 align=right>${CLANG_020:=MAC��ַ}</td>
	<td width=120 align=right>${CLANG_021:=�ۼ�����}</td>
	<td width=120 align=right>${CLANG_022:=�ۼ�����}</td>
	<td width=120 align=right>${CLANG_023:=����bps}</td>
	<td width=*   align=right>${CLANG_024:=����bps}</td>
</tr>
<tr id=row5>
	<td align=right>${usrname}</td>
	<td align=right>${lmacstr}</td>
	<td align=right id=ipoutbytes>${outbytes}</td>
	<td align=right id=ipinbytes>${inbytes}</td>
	<td align=right id=ipbpsout>${bpsout}</td>
	<td align=right id=ipbpsin>${bpsin}</td>
</tr>
</table>

<table width=800 border=0 cellspacing=1 cellpadding=1>
<tr id=tblhdr>
	<td width=160 align=right>${CLANG_025:=��������(��/��,kbps)}</td>
	<td width=130 align=right>${CLANG_026:=����ʱ��(��)}</td>
	<td width=120 align=right>${CLANG_014:=������}</td>
	<td width=120 align=right>${CLANG_027:=��������}</td>
	<td width=120 align=right>${CLANG_028:=����(IE/CH/��Ȩ)}</td>
	<td width=*   align=right>${CLANG_029:=�ƶ��ն�}</td>
</tr>
<tr id=row1>
	<td align=right>${ratein}/${rateout}</td>
	<td align=right id=iplifetime>${life_tmstr}</td>
	<td align=right id=ipflowcnt>${flowcnt}</td>
	<td align=right id=ipqqcnt>${qqcnt}/${accountcnt}</td>
	<td align=right id=ipcookie>${iecookie}/${chromecookie}/${weightcookie}</td>
	<td align=right id=ipmstcnt>${mstcnt}</td>
</tr>
</table>"
}


WEB_LOGGER()
{
	local logfile
	local curtime

	if [ -e /usr/ramdisk/datalog/keepme ]; then
		localfile="/usr/ramdisk/datalog/web_`date +%Y.%m.%d`.log"
	else
		localfile="${DATAPATH}/web_`date +%Y.%m.%d`.log"
	fi

	curtime=`date +%Y.%m.%d/%H:%M:%S`
	echo "${curtime} ${REMOTE_ADDR} ${PANABIT_USER} $1 $2" >> ${localfile}
	sync
	sync
}


XSS_RETERR()
{
	echo "<body>"
	echo "<div style='color:#999;font-size:22px;width:400px;height:400px;margin:100px auto'>"
	echo "${CLANG_031:=�����а����Ƿ��ַ���}"
	echo "</div>"
	echo "</body>"
	echo "</html>"
	exit 0
}


XSS_FILTER()
{
	xss_verify_enable="off"
	xss_verify_mode="black"
	xss_verify_rule="<>/()"

	[ -f "/usr/ramdisk/web_secure.conf" ] && . /usr/ramdisk/web_secure.conf
	
	[ "${xss_verify_enable}" = "off" ] && return

	file_upload=`echo "${CONTENT_TYPE}" | grep "multipart/form-data"`
	[ "${file_upload}" != "" ] && return

	[ "${URLENCODE}" = "" -a "${QUERY_STRING}" = "" ] && return

	get_str=`${URLENCODE} -d ${QUERY_STRING}`
	post_str=`${URLENCODE} -d  ${POST_STRING}`

	for line in "${get_str}" "${post_str}"
	do
		for str in `echo "${line}" | tr "&" " "`
		do
			exist=`echo ${str} | grep "=" `
			[ "${exist}" = "" ] && XSS_RETERR

			awk -v str="${str}" -v mode="${xss_verify_mode}" -v rule=${xss_verify_rule} \
			'BEGIN{
				for(i = 1; i <= length(str); i++){
					char = substr(str, i, 1);

					if (char == "`") exit 1;
					if (char == " " || char == "-" || char == "=" || char == "_" || char == ".") continue;

					if (mode == "black") {
						for(x = 1; x < length(rule); x++){
							r = substr(rule, x, 1);
							if(char == r) exit 1;
						}
					} else {
						r = sprintf("[%s]", rule);
						if (char !~ r) exit 1;
					}
				}
			}'

			[ $? -ne 0 ] && XSS_RETERR
		done
	done
}


string_verify()
{
	local errmsg
	local sysname="$1"

	# verify it
	errmsg=`echo ${sysname} | grep "[&|\||>|-|(|)]"`
	[ "${errmsg}" != "" ] && return 0

	errmsg=`echo ${CGI_sysname} | grep "\.conf"`
	[ "${errmsg}" != "" ] && return 0

	return 1
}


cgi_show_iftablist()
{
	printf "${CLANG_01:=��ǰ״̬}#/cgi-bin/Monitor/if_show?name=$1 "
	printf "${CLANG_030:=ʵʱ����}#/cgi-bin/Monitor/ifpxy_rtgraph?name=$1 "
	printf "${CLANG_03:=��ʷ����}#/cgi-bin/Monitor/if_graph?time=day&name=$1"
}


cgi_show_pxytablist()
{
	if [ "${type}" = "" ]; then
		type=`${FLOWEYE} nat getproxy ${1} | grep "^type=" | cut -d"=" -f2`
	fi

	if [ "${type}" = "rtif" ]; then
		printf "${CLANG_04:=��������}#/cgi-bin/Route/iflan_edit?iflanname=$1 "
		printf "${CLANG_05:=DHCP����}#/cgi-bin/Route/dhcpsvr_edit?id=$1 "
		printf "${CLANG_06:=��ǰ״̬}#/cgi-bin/Monitor/proxy_show?proxyname=$1 "
		printf "${CLANG_07:=��ʷ����}#/cgi-bin/Monitor/proxy_graph?time=day&proxyname=$1 "
		printf "${CLANG_08:=��·��־}#/cgi-bin/Monitor/proxy_logshow?proxyname=$1"
	elif [ "${type}" = "rtif6" ]; then
		printf "${CLANG_04:=��������}#/cgi-bin/Route/iflan_edit?iflanname=$1 "
		printf "${CLANG_06:=��ǰ״̬}#/cgi-bin/Monitor/proxy_show?proxyname=$1 "
		printf "${CLANG_07:=��ʷ����}#/cgi-bin/Monitor/proxy_graph?time=day&proxyname=$1 "
		printf "${CLANG_08:=��·��־}#/cgi-bin/Monitor/proxy_logshow?proxyname=$1"
	elif [ "${type}" = "iwansvc" ]; then
		printf "${CLANG_04:=��������}#/cgi-bin/Route/iwansvr_edit?proxyname=$1 "
		printf "${CLANG_07:=��ʷ����}#/cgi-bin/Monitor/proxy_graph?time=day&proxyname=$1 "
		printf "${CLANG_08:=��·��־}#/cgi-bin/Monitor/proxy_logshow?proxyname=$1 "
		printf "${CLANG_010:=�����û�}#/cgi-bin/Monitor/proxy_iwanusers?proxyname=$1"
	elif [ "${type}" = "posvrif" ]; then
		printf "${CLANG_04:=��������}#/cgi-bin/Pppoe/pppoesvr_edit?name=$1 "
		printf "${CLANG_06:=��ǰ״̬}#/cgi-bin/Monitor/proxy_show?proxyname=$1 "
		printf "${CLANG_07:=��ʷ����}#/cgi-bin/Monitor/proxy_graph?time=day&proxyname=$1 "
		printf "${CLANG_08:=��·��־}#/cgi-bin/Monitor/proxy_logshow?proxyname=$1"
	else
		printf "${CLANG_04:=��������}#/cgi-bin/Route/proxy_edit?proxyname=$1 "
		printf "${CLANG_06:=��ǰ״̬}#/cgi-bin/Monitor/proxy_show?proxyname=$1 "
		printf "${CLANG_02:=ʵʱ����}#/cgi-bin/Monitor/proxy_rtgraph?name=$1&type=${type} "
		printf "${CLANG_09:=TOPӦ��}#/cgi-bin/Monitor/proxy_apprate?link=$1 "
		printf "${CLANG_07:=��ʷ����}#/cgi-bin/Monitor/proxy_graph?time=day&proxyname=$1 "
		printf "${CLANG_08:=��·��־}#/cgi-bin/Monitor/proxy_logshow?proxyname=$1"
	fi
}

TMPPATH=${PGPATH}/admin/tmp
MAXPRI=6
ADMIN_NAME="admin"
[ "${TOPSEC}" != "" ] && ADMIN_NAME="superman"

#
# Show CGI header
#
echo "<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\">
<head><title>${CGI_browsertitle}</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">
<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\">
<META HTTP-EQUIV=\"Cache-Control\" content=\"no-cache\">
<link href=\"/img/p2p.css\" type=\"text/css\" rel=\"stylesheet\">
<script type='text/javascript' src='/img/jq.js'></script>
<script type='text/javascript' src='/html/assert/layui.all.js'></script></head>"


XSS_FILTER


